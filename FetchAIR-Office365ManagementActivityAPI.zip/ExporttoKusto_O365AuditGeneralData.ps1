<#
.SYNOPSIS
    This script was written to store events to azure data explorer (Kusto)
.DESCRIPTION
    This script will do the following things
        o	Read input file from blob storage account
        o	Bulk insert into Kusto

.PARAMETER KustoDataMappingName
    Specify Kusto schema name to match with the taget table's schema.
    This is to ensure data integrity between both the systems
.PARAMETER FileNametoProcess
    Specify name of the file in storage account which contains filtered o365 audit events
 #>

[CmdletBinding()]
param(
        [Parameter()] [String] $KustoDataMappingName,
        [Parameter()] [String] $FileNametoProcess
     )

# Initialize run as account
function global:Get-RunAsConnection{
    $RunAsConnection = Get-AutomationConnection -Name "AzureRunAsConnection"
    Connect-AzAccount -ServicePrincipal -Tenant $RunAsConnection.TenantId -ApplicationId $RunAsConnection.ApplicationId -CertificateThumbprint $RunAsConnection.CertificateThumbprint | Out-Null
    Set-AzContext -SubscriptionId $RunAsConnection.SubscriptionID  | Out-Null
}

# Assign initial variables from automation account and get secrets from keyvault
function VariableInitialization {
    # Get name of the Key Vault where we have secrets stored (used to access o365 management API, Storage account, Kusto etc)
    $KeyVaultName = Get-AutomationVariable -Name "KeyVaultName"
    $global:StorageAccountforBlobstorageAccessKey	= (Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "StorageAccountforBlobstorageAccessKey").SecretValueText
    $global:StorageAccountforFileShareAccessKey = (Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "StorageAccountforFileShareAccessKey2").SecretValueText
    $global:KustoAccessAppKey = (Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "KustoAccessAppKey").SecretValueText
    $global:ClientSecrettoAccessO365 = (Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "ClientSecrettoAccessO365").SecretValueText
    
    # Following variables are used to know the storage account to use and accessing storage account 
    $global:StorageAccountforFileShare	= Get-AutomationVariable -Name "StorageAccountforFileShare"
    $global:FileShareNameinStorageAccount	= Get-AutomationVariable -Name "FileShareNameinStorageAccount"
    #$global:StorageAccountforFileShareAccessKey	= Get-AutomationVariable -Name "StorageAccountforFileShareAccessKey"
    $global:PathforKustoExportDlls	= Get-AutomationVariable -Name "PathforKustoExportDlls"
    $global:StorageAccountforBlobstorage	= Get-AutomationVariable -Name "StorageAccountforBlobstorage"
    $global:BlobStorageContainerName	= Get-AutomationVariable -Name "BlobStorageContainerName"
    #$global:StorageAccountforBlobstorageAccessKey	= Get-AutomationVariable -Name "StorageAccountforBlobstorageAccessKey"
    
    # Create app of type Web app / API in Azure AD, generate a Client Secret, and update the client id and client secret here
    $global:ClientIDtoAccessO365	= Get-AutomationVariable -Name "ClientIDtoAccessO365"
    #$global:ClientSecrettoAccessO365	= Get-AutomationVariable -Name "ClientSecrettoAccessO365"
    
    # Get the tenant GUID from Properties | Directory ID under the Azure Active Directory section
    $global:MicrosoftLoginURL	= Get-AutomationVariable -Name "MicrosoftLoginURL"
    $global:O365TenantDomain	= Get-AutomationVariable -Name "O365TenantDomain"
    $global:O365TenantGUID	= Get-AutomationVariable -Name "O365TenantGUID"
    $global:O365ResourceUrl	= Get-AutomationVariable -Name "O365ResourceUrl"
    $global:KustoClusterName	= Get-AutomationVariable -Name "KustoClusterName"
    $global:KustoDatabaseName	= Get-AutomationVariable -Name "KustoDatabaseName"
    $global:KustoTableName	= Get-AutomationVariable -Name "KustoTableName"
    $global:KustoAccessAppId	= Get-AutomationVariable -Name "KustoAccessAppId"
    $global:TenantIdforKustoAccessApp = Get-AutomationVariable -Name "TenantIdforKustoAccessApp"
    #$global:KustoAccessAppKey	= Get-AutomationVariable -Name "KustoAccessAppKey"
    $global:authority = "https://login.microsoftonline.com/$TenantIdforKustoAccessApp"   # TenantId of Application used to access Kusto, by default it looks in microsoft.com, so if your application belongs to different app 

    # we use below file to hold the time stamp counter (last processed time). Useful to identify delta events
    $global:lastProcessedDateTimeCounter = "last_processed_date_blob.txt"

    $global:StorageAccountContext = New-AzStorageContext -StorageAccountName $StorageAccountforBlobstorage -StorageAccountKey $StorageAccountforBlobstorageAccessKey
    $global:StorageAccountforFileShare	= Get-AutomationVariable -Name "StorageAccountforFileShare"
    $global:StorageAccountContext_fileShare =  New-AzStorageContext -StorageAccountName $StorageAccountforBlobstorage -StorageAccountKey $StorageAccountforFileShareAccessKey
    $global:LocalDestinationPathforDLLs = "C:\Modules\User\ExportToKustoDLLs"

    #Automation account details
    $global:AutomationAccountName	= Get-AutomationVariable -Name "AutomationAccountName"
    $global:AutomationAccountResourceGroupName	= Get-AutomationVariable -Name "AutomationAccountResourceGroupName"
    $global:RunbookNameforGetAuditDataBlobURIs	= Get-AutomationVariable -Name "RunbookNameforGetAuditDataBlobURIs"
    $global:RunbookNameforGetAuditDataFromURIs	= Get-AutomationVariable -Name "RunbookNameforGetAuditDataFromURIs"
    $global:RunbookNameforExportDatatoKusto	= Get-AutomationVariable -Name "RunbookNameforExportDatatoKusto"

    $global:CurrentJobId = $PsPrivateMetaData.JobId.Guid
}
    
# This gets required libreay for Kusto ingestion from File share
function LoadRequiredModulesforKusto {
    try{
        $RequireDlls = Get-AzStorageFile -ShareName $FileShareNameinStorageAccount -Path $PathforKustoExportDlls -Context $StorageAccountContext_fileShare| Get-AzStorageFile | Select-Object Name
        foreach ($file in $RequireDlls.Name)
            {
                $SourcePath = Join-Path -Path $PathforKustoExportDlls -Childpath $file
                $DestinationPath = Join-Path -Path "$LocalDestinationPathforDLLs/$CurrentJobId" -Childpath $file    
                Get-AzStorageFileContent -ShareName $FileShareNameinStorageAccount -Context $StorageAccountContext_fileShare -path $SourcePath -Destination $DestinationPath -Force
            }
    }
    catch{
        Write-Error "Some problem from reading storage account, exitig.  Re-process data between  $MinTimeinContentUris and $MaxTimeinContentUris "
        Exit
    }
    
    try {
        [System.Reflection.Assembly]::LoadFrom("C:\Modules\User\ExportToKustoDLLs\$CurrentJobId\Kusto.Data.dll")
        [System.Reflection.Assembly]::LoadFrom("C:\Modules\User\ExportToKustoDLLs\$CurrentJobId\Kusto.Ingest.dll")
    } 
    catch {
            foreach($ex in $_.Exception.LoaderExceptions) {
                Write-Warning $ex
            }
            Write-Error "Can't upload to Kusto as a required DLL is missing.  Re-process data between  $MinTimeinContentUris and $MaxTimeinContentUris "
            Exit
    }

}

# Read Kusto input file
function Get-DatatoExporttoKusto{
    $file_name_to_read_data = $FileNametoProcess  
    $temp = "temp.json"
    $Blob = Get-AzStorageBlobContent -Container $BlobStorageContainerName -Blob $file_name_to_read_data -Context $StorageAccountContext -Destination $temp -Force
    $contents = Get-Content $temp -Raw -ErrorAction:SilentlyContinue
    $global:AllData = ConvertFrom-Json -InputObject $contents
}

# Export data to Kusto 
function global:Exporto365AuditDatatoKusto{
    if($KustoDataMappingName -eq "O365AuditGeneralData")
    {
        $mappings = New-Object System.Collections.ArrayList
        $mappings.AddRange((
            [System.Tuple]::Create("CreationTime", "System.DateTime"),
            [System.Tuple]::Create("StartTimeUtc", "System.DateTime"),
            [System.Tuple]::Create("LastUpdateTimeUtc", "System.DateTime"),
            [System.Tuple]::Create("EndTimeUtc", "System.DateTime"),
            [System.Tuple]::Create("Id", "System.String"),
            [System.Tuple]::Create("Operation", "System.String"),
            [System.Tuple]::Create("OrganizationId", "System.String"),
            [System.Tuple]::Create("RecordType", "System.Int32"),
            [System.Tuple]::Create("ResultStatus", "System.String"),
            [System.Tuple]::Create("UserKey", "System.String"),
            [System.Tuple]::Create("UserType", "System.Int32"),
            [System.Tuple]::Create("Version", "System.Int32"),
            [System.Tuple]::Create("Workload", "System.String"),
            [System.Tuple]::Create("ClientIP", "System.String"),
            [System.Tuple]::Create("ObjectId", "System.String"),
            [System.Tuple]::Create("UserId", "System.String"),
            [System.Tuple]::Create("CrmOrganizationUniqueName", "System.String"),
            [System.Tuple]::Create("Fields", "System.Object"),
            [System.Tuple]::Create("InstanceUrl", "System.String"),
            [System.Tuple]::Create("ItemType", "System.String"),
            [System.Tuple]::Create("ItemUrl", "System.String"),
            [System.Tuple]::Create("UserAgent", "System.Object"),
            [System.Tuple]::Create("CorrelationId", "System.String"),
            [System.Tuple]::Create("EntityId", "System.String"),
            [System.Tuple]::Create("EntityName", "System.String"),
            [System.Tuple]::Create("Message", "System.String"),
            [System.Tuple]::Create("PrimaryFieldValue", "System.Object"),
            [System.Tuple]::Create("Query", "System.String"),
            [System.Tuple]::Create("QueryResults", "System.Object"),
            [System.Tuple]::Create("ServiceContextId", "System.String"),
            [System.Tuple]::Create("ServiceContextIdType", "System.String"),
            [System.Tuple]::Create("ServiceName", "System.String"),
            [System.Tuple]::Create("SystemUserId", "System.String"),
            [System.Tuple]::Create("UserUpn", "System.String"),
            [System.Tuple]::Create("Name", "System.String"),
            [System.Tuple]::Create("Data", "System.Object"),
            [System.Tuple]::Create("Actions", "System.Object"),
            [System.Tuple]::Create("Severity", "System.String"),
            [System.Tuple]::Create("Source", "System.String"),
            [System.Tuple]::Create("AlertId", "System.String"),
            [System.Tuple]::Create("AlertLinks", "System.Object"),
            [System.Tuple]::Create("AlertType", "System.String"),
            [System.Tuple]::Create("Category", "System.String"),
            [System.Tuple]::Create("Comments", "System.String"),
            [System.Tuple]::Create("PolicyId", "System.String"),
            [System.Tuple]::Create("Status", "System.String"),
            [System.Tuple]::Create("FlowConnectorNames", "System.String"),
            [System.Tuple]::Create("FlowDetailsUrl", "System.String"),
            [System.Tuple]::Create("LicenseDisplayName", "System.String"),
            [System.Tuple]::Create("SharingPermission", "System.String"),
            [System.Tuple]::Create("UserTypeInitiated", "System.String"),
            [System.Tuple]::Create("DetectionMethod", "System.String"),
            [System.Tuple]::Create("DetectionType", "System.String"),
            [System.Tuple]::Create("EventDeepLink", "System.String"),
            [System.Tuple]::Create("DeepLinkUrl", "System.String"),
            [System.Tuple]::Create("InvestigationType", "System.String"),
            [System.Tuple]::Create("InvestigationName", "System.String"),
            [System.Tuple]::Create("InvestigationId", "System.String"),
            [System.Tuple]::Create("InternetMessageId", "System.String"),
            [System.Tuple]::Create("MessageTime", "System.String"),
            [System.Tuple]::Create("NetworkMessageId", "System.String"),
            [System.Tuple]::Create("P1Sender", "System.String"),
            [System.Tuple]::Create("P2Sender", "System.String"),
            [System.Tuple]::Create("Recipients", "System.String"),
            [System.Tuple]::Create("SenderIp", "System.String"),
            [System.Tuple]::Create("Subject", "System.String"),
            [System.Tuple]::Create("Verdict", "System.String"),
            [System.Tuple]::Create("AdditionalInfo", "System.String"),
            [System.Tuple]::Create("AppName", "System.String"),
            [System.Tuple]::Create("ActivityId", "System.String"),
            [System.Tuple]::Create("RequestId", "System.String"),
            [System.Tuple]::Create("IsSuccess", "System.String"),
            [System.Tuple]::Create("DashboardId", "System.String"),
            [System.Tuple]::Create("WorkspaceId", "System.String"),
            [System.Tuple]::Create("DashboardName", "System.String"),
            [System.Tuple]::Create("WorkSpaceName", "System.String"),
            [System.Tuple]::Create("ItemName", "System.String"),
            [System.Tuple]::Create("SkypeForBusinessEventType", "System.String"),
            [System.Tuple]::Create("TenantName", "System.String"),
            [System.Tuple]::Create("CmdletVersion", "System.String"),
            [System.Tuple]::Create("ExternalAccess", "System.String"),
            [System.Tuple]::Create("ObjectName", "System.String"),
            [System.Tuple]::Create("Parameters", "System.Object"),
            [System.Tuple]::Create("ActorYammerUserId", "System.String"),
            [System.Tuple]::Create("ActorUserId", "System.String"),
            [System.Tuple]::Create("VersionId", "System.String"),
            [System.Tuple]::Create("Field", "System.String"),
            [System.Tuple]::Create("FileName", "System.String"),
            [System.Tuple]::Create("AuditGeneralContentUri", "System.String")
        ));
    }
    else {
        Write-Error "Not able to find schema mapping with Kusto, verify mapping present in this script or not. Re-process data between  $MinTimeinContentUris and $MaxTimeinContentUris "
        Exit
    }
    try{
        $adminUrl = "https://$KustoClusterName.kusto.windows.net:443;Fed=true"
        $ingestUrl = "https://ingest-$KustoClusterName.kusto.windows.net:443;Fed=true"
        # Connect to cluster
        $kcsb = New-Object Kusto.Data.KustoConnectionStringBuilder ($adminUrl, $KustoDatabaseName)
        # Authenticate as AAD Application
        $kcsb = $kcsb.WithAadApplicationKeyAuthentication($KustoAccessAppId, $KustoAccessAppKey, $authority)
        # Admin provider lets us run admin commands
        $adminProvider = [Kusto.Data.Net.Client.KustoClientFactory]::CreateCslAdminProvider($kcsb) 
    
        $mappingName = 'MCAS_json_direct'
    
        $columnMappingForCreate = New-Object 'System.Collections.Generic.List[System.Tuple[string,string]]'
        $mappings | ForEach-Object {
            $columnMappingForCreate.Add($_)
            }
        $createCommand = [Kusto.Data.Common.CslCommandGenerator]::GenerateTableCreateCommand($KustoTableName, $columnMappingForCreate, $true)
        $createCommand += " with (docstring = ""Data extracted via PS"")"
    
        $columnMappingForMapping = New-Object 'System.Collections.Generic.List[Kusto.Data.Common.JsonColumnMapping]'
        $mappings | ForEach-Object {
            $columnName = $_.Item1
            $mapping = New-Object Kusto.Data.Common.JsonColumnMapping
            $mapping.ColumnName = $columnName
            $mapping.JsonPath = "`$.$columnName"
            $columnMappingForMapping.Add($mapping)
        }
        $mappingCommand = [Kusto.Data.Common.CslCommandGenerator]::GenerateTableJsonMappingCreateCommand($KustoTableName, $mappingName, $columnMappingForMapping)
    
        #Write-Output "6. Now creating table (if not available) via createCommand"
    
        try {
            $adminProvider.ExecuteControlCommand($createCommand)
        } catch {
            Write-Error "Problem in creating table $($_.Exception.Message)"
            #Exit
        }
    
        #Write-Output "7. Now adding JSON mapping via mappingCommand"
    
        try {
            $adminProvider.ExecuteControlCommand($mappingCommand)
        } catch {
            # Write-Error "Problem in mapping fields $($_.Exception.Message)"
            # Exit
        }
    
        Write-Output "Starting data ingestion into Kusto: $KustoClusterName Database: $KustoDatabaseName Table: $KustoTableName"
    
        # Update the data to be in text format so it can be properly uploaded
        $jsonlist = $AllData | Foreach-Object {
            $_ | ConvertTo-Json -Compress -Depth 100
        }
        $jsontext = $jsonlist -join "`n"
    
        $kcsb = New-Object Kusto.Data.KustoConnectionStringBuilder ($ingestUrl, $KustoDatabaseName)
        # Authenticate as AAD Application
        $kcsb = $kcsb.WithAadApplicationKeyAuthentication($KustoAccessAppId, $KustoAccessAppKey, $authority)
    
        # Ingest provider lets us ingest big data
        $ingestProvider = [Kusto.Ingest.KustoIngestFactory]::CreateQueuedIngestClient($kcsb)
    
        # Specify properties for ingesting
        $ingestProperties = New-Object Kusto.Ingest.KustoQueuedIngestionProperties($KustoDatabaseName, $KustoTableName)
        $ingestProperties.JSONMappingReference = $mappingName
        $ingestProperties.Format = [Kusto.Data.Common.DataSourceFormat]::'json'
    
        # Open the raw data for uploading, then upload
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($jsontext)
        $stream = New-Object System.IO.MemoryStream(,$bytes)
        $streamSourceOptions= New-Object Kusto.Ingest.StreamSourceOptions;
        $streamSourceOptions.LeaveOpen=$false;
        $ingestProvider.IngestFromStreamAsync($stream, $ingestProperties, $streamSourceOptions)
        Write-Output "Finished upload to Kusto. Total records inserted are $($AllData.Count). Data will be available in $KustoClusterName.$KustoDatabaseName.$KustoTableName shortly"
    }
    catch{
        Write-Error "Caught with some exception while inserting data into Kusto.  Re-process data between  $MinTimeinContentUris and $MaxTimeinContentUris . Exception Message: $($_.Exception.Message)"
        Exit
    }
}

# Rename storage blob
function Rename-AzureStorageBlob {
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, Position = 0)]
        [Microsoft.WindowsAzure.Commands.Common.Storage.ResourceModel.AzureStorageBlob]$Blob,

        [Parameter(Mandatory = $true, Position = 1)]
        [string]$NewName
    )

    Process {
        $blobCopyAction = Start-AzStorageBlobCopy -ICloudBlob $Blob.ICloudBlob -DestBlob $NewName -Context $Blob.Context -DestContainer $Blob.ICloudBlob.Container.Name
        $status = $blobCopyAction | Get-AzStorageBlobCopyState
        while ($status.Status -ne 'Success') {
            $status = $blobCopyAction | Get-AzStorageBlobCopyState
            Start-Sleep -Milliseconds 50
        }
        $Blob | Remove-AzStorageBlob -Force
    }
}

# Rename the blob having content for o365 audit data blobs into separate folder "processed"
function MarkProcessedFiles {
    Get-AzStorageBlob -Container $BlobStorageContainerName -Context $StorageAccountContext -Blob $FileNametoProcess | Rename-AzureStorageBlob -NewName "processed/$FileNametoProcess"
    Write-Output "Renamed the data file $FileNametoProcess successfully"    
}

#Function calls start from here
Get-RunAsConnection
VariableInitialization # Variable initialization
LoadRequiredModulesforKusto # For exporting data into Kusto, we would require some dependent libraries, we load here
Get-DatatoExporttoKusto # Get the data to export to Kusto (Azure data explorer)
Exporto365AuditDatatoKusto # Export data to Kusto
MarkProcessedFiles # After export, mark file inside blob storage as processed