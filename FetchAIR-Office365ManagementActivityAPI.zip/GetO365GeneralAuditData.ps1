<#
.SYNOPSIS
    This script was written to fetch o365 audit data for automated investigation runbook (AIR) user submission phinging events
.DESCRIPTION
    This script will do the following things
        o	Read and parse blobs list from storage account 
        o	Read content inside each blob
        o	Filter required events
        o	Store results into storage acocunt
        o	Invoke data ingestion runbook for exporting data into azure data explorer (Kusto)

.PARAMETER BlobsUriListFileName
    File name containing o365 audit data blobs.
 #>


[CmdletBinding()]
param(
        [Parameter()] [String] $BlobsUriListFileName
    )

# Initialize run as account
function Get-RunAsConnection{
    $RunAsConnection = Get-AutomationConnection -Name "AzureRunAsConnection"
    Connect-AzAccount -ServicePrincipal -Tenant $RunAsConnection.TenantId -ApplicationId $RunAsConnection.ApplicationId -CertificateThumbprint $RunAsConnection.CertificateThumbprint | Out-Null
    Set-AzContext -SubscriptionId $RunAsConnection.SubscriptionID  | Out-Null
}

# Assign initial variables from automation account and get secrets from keyvault
function VariableInitialization {
    # Get name of the Key Vault where we have secrets stored (used to access o365 management API, Storage account, Kusto etc)
    $KeyVaultName = Get-AutomationVariable -Name "KeyVaultName"
    $global:StorageAccountforBlobstorageAccessKey	= (Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "StorageAccountforBlobstorageAccessKey").SecretValueText
    $global:StorageAccountforFileShareAccessKey = (Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "StorageAccountforFileShareAccessKey").SecretValueText
    $global:KustoAccessAppKey = (Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "KustoAccessAppKey").SecretValueText
    $global:ClientSecrettoAccessO365 = (Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "ClientSecrettoAccessO365").SecretValueText
    
    # Following variables are used to know the storage account to use and accessing storage account 
    $global:StorageAccountforFileShare	= Get-AutomationVariable -Name "StorageAccountforFileShare"
    $global:FileShareNameinStorageAccount	= Get-AutomationVariable -Name "FileShareNameinStorageAccount"
    #$global:StorageAccountforFileShareAccessKey	= Get-AutomationVariable -Name "StorageAccountforFileShareAccessKey"
    $global:PathforKustoExportDlls	= Get-AutomationVariable -Name "PathforKustoExportDlls"
    $global:StorageAccountforBlobstorage	= Get-AutomationVariable -Name "StorageAccountforBlobstorage"
    $global:BlobStorageContainerName	= Get-AutomationVariable -Name "BlobStorageContainerName"
    #$global:StorageAccountforBlobstorageAccessKey	= Get-AutomationVariable -Name "StorageAccountforBlobstorageAccessKey"
    
    # Create app of type Web app / API in Azure AD, generate a Client Secret, and update the client id and client secret here
    $global:ClientIDtoAccessO365	= Get-AutomationVariable -Name "ClientIDtoAccessO365"
    #$global:ClientSecrettoAccessO365	= Get-AutomationVariable -Name "ClientSecrettoAccessO365"
    
    # Get the tenant GUID from Properties | Directory ID under the Azure Active Directory section
    $global:MicrosoftLoginURL	= Get-AutomationVariable -Name "MicrosoftLoginURL"
    $global:O365TenantDomain	= Get-AutomationVariable -Name "O365TenantDomain"
    $global:O365TenantGUID	= Get-AutomationVariable -Name "O365TenantGUID"
    $global:O365ResourceUrl	= Get-AutomationVariable -Name "O365ResourceUrl"
    $global:KustoClusterName	= Get-AutomationVariable -Name "KustoClusterName"
    $global:KustoDatabaseName	= Get-AutomationVariable -Name "KustoDatabaseName"
    $global:KustoTableName	= Get-AutomationVariable -Name "KustoTableName"
    $global:KustoAccessAppId	= Get-AutomationVariable -Name "KustoAccessAppId"
    #$global:KustoAccessAppKey	= Get-AutomationVariable -Name "KustoAccessAppKey"

    # we use below file to hold the time stamp counter (last processed time). Useful to identify delta events
    $global:lastProcessedDateTimeCounter = "last_processed_date_blob.txt"

    $global:StorageAccountContext = New-AzStorageContext -StorageAccountName $StorageAccountforBlobstorage -StorageAccountKey $StorageAccountforBlobstorageAccessKey
    $global:LocalDestinationPathforDLLs = "C:\Modules\User\ExportToKustoDLLs"

    #Automation account details
    $global:AutomationAccountName	= Get-AutomationVariable -Name "AutomationAccountName"
    $global:AutomationAccountResourceGroupName	= Get-AutomationVariable -Name "AutomationAccountResourceGroupName"
    $global:RunbookNameforGetAuditDataBlobURIs	= Get-AutomationVariable -Name "RunbookNameforGetAuditDataBlobURIs"
    $global:RunbookNameforGetAuditDataFromURIs	= Get-AutomationVariable -Name "RunbookNameforGetAuditDataFromURIs"
    $global:RunbookNameforExportDatatoKusto	= Get-AutomationVariable -Name "RunbookNameforExportDatatoKusto"
}
    
# Get authentication token to access o365 management API
function global:Get-Oauth
    {
        $global:body = @{grant_type="client_credentials";tenant=$O365TenantDomain;client_id=$ClientIDtoAccessO365;client_secret=$ClientSecrettoAccessO365;scope=$O365ResourceURL}
        $global:oauth = Invoke-RestMethod -Method Post -Uri "$MicrosoftLoginURL/$O365TenantDomain/oauth2/v2.0/token" -Body $body
        $global:oauth_time = (get-date).ToUniversalTime()
        $global:headerParams = @{'Authorization'="$($oauth.token_type) $($oauth.access_token)"}
    }
    
# Get the content inside file / storage account blob
# BlobsUriListFileName can be passed as parameters. Here we are using as global variable.
function Get-FileContent {
    $file_name_to_read_data = $BlobsUriListFileName  
    $temp = "temp.json"
    $Blob = Get-AzStorageBlobContent -Container $BlobStorageContainerName -Blob $file_name_to_read_data -Context $StorageAccountContext -Destination $temp -Force
    $contents = Get-Content $temp -Raw -ErrorAction:SilentlyContinue
    $global:BlobsUriList = ConvertFrom-Json -InputObject $contents
    $global:MaxTimeinContentUris = (($BlobsUriList).Substring(116,21) | Sort-Object ) | Select-Object -Last 1
    $global:MinTimeinContentUris = (($BlobsUriList).Substring(116,21) | Sort-Object ) | Select-Object -First 1
    Write-Output "Total Blob URIs need to process -  $($BlobsUriList.Count)"      
}

# Get o365 audit events from blobs.
# Here  BlobsUriList can be used as parameter also. We are using global variable
function Get-DatafromAuditDataContentURI {
    $loopCounter=0
    $global:AllData = @();
    $UriCounter = 0
    while($UriCounter -lt $BlobsUriList.Length){
    $line = $BlobsUriList[$UriCounter]
    $CurrentTime = (get-date).ToUniversalTime()
    $TimefromLastAuth = $CurrentTime - $oauth_time
    if ($TimefromLastAuth.Minutes -gt 50) {
        Get-Oauth
    }
    $uri = $line+"?PublisherIdentifier="+$O365TenantGUID
    $events = @();
    $events = Invoke-RestMethod -Method Get -Headers $headerParams -Uri $uri 
    # Write-Output "Total events before inside blob (before filters applied) are $($events.Count)"
    $DatainCurrentLoop = @()
    write-output $events
    # Filter Condition set here. You can filter for desired events
    # For filtering, Use the available fields like Workload, Operation, OrganizationId, ResultStatus, UserKey, ClientIP, UserId etc
    $DatainCurrentLoop = $events  |  Where-Object {($_.Workload -eq "AirInvestigation" -or ($_.Workload -eq "SecurityComplianceCenter" -and $_.UserId -eq "SecurityComplianceAlerts"))}
    $DatainCurrentLoop | Add-Member -MemberType NoteProperty "AuditGeneralContentUri" -Value $line 
    $global:AllData += $DatainCurrentLoop
    $UriCounter++ 
    }
    $global:NumberofRecordstoInsert = $AllData.Count
    Write-Output "We have found total $NumberofRecordstoInsert events after filter applied. Will be inserted into Blob storage and target store"
}

# Invoke next runbook for for exporting data into azure data explorer (kusto) 
# All the o365 audit events (filtered) will be stored into storage account
function InvokeNextRunbookStoreAuditEvents {
    if($NumberofRecordstoInsert -gt 0){
        $AllData_Json = ConvertTo-Json -InputObject $AllData 
        $file_name_to_store_data = "o365auditdatastore/O365AuditGeneralData_Filtered_$MinTimeinContentUris-$MaxTimeinContentUris.json" 
        $AllData_Json | Out-File $file_name_to_store_data 
        Set-AzStorageBlobContent -Container $BlobStorageContainerName -Blob $file_name_to_store_data -File $file_name_to_store_data -Context $StorageAccountContext -Force | Out-Null
        $params = @{"FileNametoProcess"="$file_name_to_store_data";"KustoDataMappingName"="O365AuditGeneralData"}
        # Invoking next runbook to export data into Kusto
        write-output "Params: " $params
        write-output "AutomationAccountName: " $AutomationAccountName
        write-output "RunbookNameforExportDatatoKusto: " $RunbookNameforExportDatatoKusto
        write-output "AutomationAccountResourceGroupName:" $AutomationAccountResourceGroupName
        Start-AzAutomationRunbook –AutomationAccountName $AutomationAccountName –Name $RunbookNameforExportDatatoKusto -ResourceGroupName $AutomationAccountResourceGroupName –Parameters $params | Out-Null
    }   
    else {
    Write-Output "Completed reading data from blob uris. Based on conditions set, we have no records to insert, exiting"
    }
}

# Rename the blob 
function Rename-AzureStorageBlob {
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory = $true, ValueFromPipeline = $true, Position = 0)]
        [Microsoft.WindowsAzure.Commands.Common.Storage.ResourceModel.AzureStorageBlob]$Blob,
        [Parameter(Mandatory = $true, Position = 1)]
        [string]$NewName
    )

    Process {
        $blobCopyAction = Start-AzStorageBlobCopy -ICloudBlob $Blob.ICloudBlob -DestBlob $NewName -Context $Blob.Context -DestContainer $Blob.ICloudBlob.Container.Name
        $status = $blobCopyAction | Get-AzStorageBlobCopyState
        while ($status.Status -ne 'Success') {
            $status = $blobCopyAction | Get-AzStorageBlobCopyState
            Start-Sleep -Milliseconds 50
        }
        $Blob | Remove-AzStorageBlob -Force
    }
}

# Rename the blob having content for o365 audit data blobs into separate folder "processed"
function MarkProcessedFiles {
    Get-AzStorageBlob -Container $BlobStorageContainerName -Context $StorageAccountContext -Blob $BlobsUriListFileName | Rename-AzureStorageBlob -NewName "processed/$BlobsUriListFileName"
    Write-Output "Renamed the data file $BlobsUriListFileName successfully"    
}

#Function calls begin here
Get-RunAsConnection
VariableInitialization                  # Variable initialization
Get-FileContent                         # Get the list of audit data content URIs
Get-Oauth                               # Authentication with o365 management API
Get-DatafromAuditDataContentURI         # Fetches data from content URIs (Blob storage)
InvokeNextRunbookStoreAuditEvents       # Invoke the runbook to export audit data to Kusto and also stores in azure storage blob content
MarkProcessedFiles                      # Once we process the file, we mark as processed