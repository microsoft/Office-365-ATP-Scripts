<#
.SYNOPSIS
    This script was written to fetch o365 audit data blob details
.DESCRIPTION
    This script will do the following things
        o	Specifies the time range where we need to fetch o365 audit data
        o	Invoke o365 management API with the time range filter, to fetch blob urls for o365 audit events
        o	Insert o365 audit data blob urls into o365 management API automation storage account
        o	Invoke runbook to fetch o365 audit events
        We have to make sure azure resources setup before deploying this runbook.Use the document located at
 #>



# Initialize run as account
function Get-RunAsConnection{
    $RunAsConnection = Get-AutomationConnection -Name "AzureRunAsConnection"
    Connect-AzAccount -ServicePrincipal -Tenant $RunAsConnection.TenantId -ApplicationId $RunAsConnection.ApplicationId -CertificateThumbprint $RunAsConnection.CertificateThumbprint | Out-Null
    Set-AzContext -SubscriptionId $RunAsConnection.SubscriptionID  | Out-Null
}

# Assign initial variables from automation account and get secrets from keyvault
function VariableInitialization {
    # Get name of the Key Vault where we have secrets stored (used to access o365 management API, Storage account, Kusto etc)
    $KeyVaultName = Get-AutomationVariable -Name "KeyVaultName"
    $global:StorageAccountforBlobstorageAccessKey	= (Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "StorageAccountforBlobstorageAccessKey").SecretValueText
    $global:StorageAccountforFileShareAccessKey = (Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "StorageAccountforFileShareAccessKey").SecretValueText
    $global:KustoAccessAppKey = (Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "KustoAccessAppKey").SecretValueText
    $global:ClientSecrettoAccessO365 = (Get-AzKeyVaultSecret -VaultName $KeyVaultName -Name "ClientSecrettoAccessO365").SecretValueText
    
    # Following variables are used to know the storage account to use and accessing storage account 
    $global:StorageAccountforFileShare	= Get-AutomationVariable -Name "StorageAccountforFileShare"
    $global:FileShareNameinStorageAccount	= Get-AutomationVariable -Name "FileShareNameinStorageAccount"
    #$global:StorageAccountforFileShareAccessKey	= Get-AutomationVariable -Name "StorageAccountforFileShareAccessKey"
    $global:PathforKustoExportDlls	= Get-AutomationVariable -Name "PathforKustoExportDlls"
    $global:StorageAccountforBlobstorage	= Get-AutomationVariable -Name "StorageAccountforBlobstorage"
    $global:BlobStorageContainerName	= Get-AutomationVariable -Name "BlobStorageContainerName"
    #$global:StorageAccountforBlobstorageAccessKey	= Get-AutomationVariable -Name "StorageAccountforBlobstorageAccessKey"
    
    # Create app of type Web app / API in Azure AD, generate a Client Secret, and update the client id and client secret here
    $global:ClientIDtoAccessO365	= Get-AutomationVariable -Name "ClientIDtoAccessO365"
    #$global:ClientSecrettoAccessO365	= Get-AutomationVariable -Name "ClientSecrettoAccessO365"
    
    # Get the tenant GUID from Properties | Directory ID under the Azure Active Directory section
    $global:MicrosoftLoginURL	= Get-AutomationVariable -Name "MicrosoftLoginURL"
    $global:O365TenantDomain	= Get-AutomationVariable -Name "O365TenantDomain"
    $global:O365TenantGUID	= Get-AutomationVariable -Name "O365TenantGUID"
    $global:O365ResourceUrl	= Get-AutomationVariable -Name "O365ResourceUrl"
    $global:KustoClusterName	= Get-AutomationVariable -Name "KustoClusterName"
    $global:KustoDatabaseName	= Get-AutomationVariable -Name "KustoDatabaseName"
    $global:KustoTableName	= Get-AutomationVariable -Name "KustoTableName"
    $global:KustoAccessAppId	= Get-AutomationVariable -Name "KustoAccessAppId"
    #$global:KustoAccessAppKey	= Get-AutomationVariable -Name "KustoAccessAppKey"

    # we use below file to hold the time stamp counter (last processed time). Useful to identify delta events
    $global:lastProcessedDateTimeCounter = "last_processed_date_blob.txt"

    $global:StorageAccountContext = New-AzStorageContext -StorageAccountName $StorageAccountforBlobstorage -StorageAccountKey $StorageAccountforBlobstorageAccessKey
    $global:LocalDestinationPathforDLLs = "C:\Modules\User\ExportToKustoDLLs"

    #Automation account details
    $global:AutomationAccountName	= Get-AutomationVariable -Name "AutomationAccountName"
    $global:AutomationAccountResourceGroupName	= Get-AutomationVariable -Name "AutomationAccountResourceGroupName"
    $global:RunbookNameforGetAuditDataBlobURIs	= Get-AutomationVariable -Name "RunbookNameforGetAuditDataBlobURIs"
    $global:RunbookNameforGetAuditDataFromURIs	= Get-AutomationVariable -Name "RunbookNameforGetAuditDataFromURIs"
    $global:RunbookNameforExportDatatoKusto	= Get-AutomationVariable -Name "RunbookNameforExportDatatoKusto"
}

# Get authentication token to access o365 management API
function global:Get-Oauth
    {
        $global:body = @{grant_type="client_credentials";tenant=$O365TenantDomain;client_id=$ClientIDtoAccessO365;client_secret=$ClientSecrettoAccessO365;scope=$O365ResourceURL}
        $global:oauth = Invoke-RestMethod -Method Post -Uri "$MicrosoftLoginURL/$O365TenantDomain/oauth2/v2.0/token" -Body $body
        $global:oauth_time = (get-date).ToUniversalTime()
        $global:headerParams = @{'Authorization'="$($oauth.token_type) $($oauth.access_token)"}
    }

# Gest last processed/run time from blob storage.   
function Get-TimeIntervaltoProcess
    { 
        $last_processed_date_blob_name = $lastProcessedDateTimeCounter  
        $temp = "temp.txt"
        try {   
        $BlobName = Get-AzStorageBlob -Blob $lastProcessedDateTimeCounter -Container $BlobStorageContainerName -Context $StorageAccountContext -ErrorAction Stop
        $Blob = Get-AzStorageBlobContent -Container $BlobStorageContainerName -Blob $last_processed_date_blob_name -Context $StorageAccountContext -Destination $temp -Force
        $contents = Get-Content $temp -Raw -ErrorAction:SilentlyContinue
        $contents = $contents.Trim()
        }
        catch [Microsoft.WindowsAzure.Commands.Storage.Common.ResourceNotFoundException]
        {
        # Add logic here to remember that the blob doesn't exist...
        Write-Host "Blob Not Found, we will assign null as file content"
        $contents = $null
        }

        if($contents.Length -le 0) {
            Write-Output "We dont find last processed time file."
            $global:startTime = (get-date).ToUniversalTime().AddHours(-23).ToString("yyyy-MM-ddTHH:mm:ss.fffffff")
            $global:startTime_datetimeformat = (get-date).ToUniversalTime().AddHours(-23)
        }
        else {
            $contents_incrementbymillisecond = (([datetime]::parseexact($contents, "yyyy-MM-ddTHH:mm:ss.fffffff", [System.Globalization.CultureInfo]::InvariantCulture))+1).ToString("yyyy-MM-ddTHH:mm:ss.fffffff")
            $global:startTime = $contents_incrementbymillisecond
            $global:startTime_datetimeformat = ([datetime]::parseexact($contents, "yyyy-MM-ddTHH:mm:ss.fffffff", [System.Globalization.CultureInfo]::InvariantCulture))+1
        }
        # We are processing data till NOW()-2 minutes , considering 2 mimutes gap to avoid any timestamp synchonization issues
        $global:endTime_datetimeformat = (get-date).ToUniversalTime().AddMinutes(-2)
        $global:endTime = (get-date).ToUniversalTime().AddMinutes(-2).ToString("yyyy-MM-ddTHH:mm:ss.fffffff")
        #if(($endTime_datetimeformat - $startTime_datetimeformat).TotalMinutes -ge 30) {
        #    $global:endTime = (([datetime]::parseexact($contents, "yyyy-MM-ddTHH:mm:ss.fffffff", [System.Globalization.CultureInfo]::InvariantCulture))+1).AddMinutes(30).ToString("yyyy-MM-ddTHH:mm:ss.fffffff")
        #}   
    }
    
# Get Blob URIs list for o365 audit.general data. 
# startTime and endTime can be passed as parameters. Here we are using as global variables
function Get-o365AuditDataBlobUrisList {
    Get-Oauth # Management API Auth
    $O365AuditGeneralEventsMainURI = "https://manage.office.com/api/v1.0/$O365TenantGUID/activity/feed/subscriptions/content?contentType=Audit.General&startTime=$startTime&endTime=$endTime" ;
    $global:AllContentUris = @();
    while([string]::IsNullOrEmpty($O365AuditGeneralEventsMainURI) -ne $true ){
        Write-Output "StartTime and endTime: " $startTime $endTime
        $pageURI = Invoke-WebRequest -Method Get -Headers $headerParams -Uri $O365AuditGeneralEventsMainURI -UseBasicParsing
        $contentURI = Invoke-RestMethod -Method Get -Headers $headerParams -Uri $O365AuditGeneralEventsMainURI
        $O365AuditGeneralEventsMainURI=$pageURI.Headers.nextPageuri| Out-String
        $global:AllContentUris = $AllContentUris + ($contentURI.contentUri)
        }
    }

# Divide the list of URIs into smaller portions, lets say 50 URIs into each portion, this will make data processing faster
function Get-ChunksDataBlobUrisList {
    if($AllContentUris.Count -gt 0){
    $global:MaxTimeinContentUris = (($AllContentUris).Substring(116,21) | Sort-Object ) | Select-Object -Last 1
    $global:MinTimeinContentUris = (($AllContentUris).Substring(116,21) | Sort-Object ) | Select-Object -First 1
    $global:MaxTimeinContentUris_String = ([datetime]::parseexact($MaxTimeinContentUris, "yyyyMMddHHmmssfffffff", [System.Globalization.CultureInfo]::InvariantCulture)).ToString("yyyy-MM-ddTHH:mm:ss.fffffff")
    $global:DataBlobUris = @();
     for ($i = 0; $i -lt $AllContentUris.Count; $i += 50) {
         $global:DataBlobUris += ,@($AllContentUris[$i..($i+49)]);   
         } 
    }
    else{
        Write-Output "No URI's found between time $startTime and $endTime"
    }
}

# Invoke next runbook for each chunk to get the degree of parlallism 
# All the blob uris will be stored into storage account
function InvokeNextRunbookGetO365GeneralAuditData {
    for ($j = 0; $j -lt $DataBlobUris.Count; $j += 1) {     
        $AllContentUris = ConvertTo-Json -InputObject $DataBlobUris[$j]
        $file_name_to_store_uri_list = "o365auditdataurilist/O365AuditGeneralDataUris_$MinTimeinContentUris-$MaxTimeinContentUris-$j.json" 
        $AllContentUris | Out-File $file_name_to_store_uri_list 
        Set-AzStorageBlobContent -Container $BlobStorageContainerName -Blob $file_name_to_store_uri_list -File $file_name_to_store_uri_list -Context $StorageAccountContext -Force | Out-Null
        $params = @{"BlobsUriListFileName"="$file_name_to_store_uri_list"}
        # Invoking next runbook to get audit events using blob uri
        Start-AzAutomationRunbook –AutomationAccountName $AutomationAccountName –Name $RunbookNameforGetAuditDataFromURIs -ResourceGroupName $AutomationAccountResourceGroupName –Parameters $params | Out-Null
      }
    Write-Output "Finished processing, we have divided into $($DataBlobUris.Count) chunks and processed, Exiting Now"
}
  
# Update the latest timestamp in blob storage account(till what time we have processed the data)
function Update-LastProcessedTimeBlob {
    $last_processed_date = $lastProcessedDateTimeCounter 
    $MaxTimeinContentUris_String | Out-File $last_processed_date 
    Set-AzStorageBlobContent -Container $BlobStorageContainerName -File $last_processed_date -Context $StorageAccountContext -Force | Out-Null    
}

#Function Calls starts from here

Get-RunAsConnection
VariableInitialization  # Variables initialization, reads the automation account variables
Get-TimeIntervaltoProcess # We need startTime and endTime to invoke O365 Management API, will get this
Get-o365AuditDataBlobUrisList # Get the list of all audit data URIs (locations), o365 audit events stored here at this locations
Get-ChunksDataBlobUrisList # Its better to divide into smaller parts for paraller processing, this will helps to divide the URIs
InvokeNextRunbookGetO365GeneralAuditData # Once we have URIs, now we need to get he data, this runbook helps to get the data from given blob locations
Update-LastProcessedTimeBlob # We have to update the last processed timestamp (will be used in future runs)